public class TiposDatos {
    public static void main(String[] args) {
        int edad = 20;
        double altura = 1.75;
        boolean estudiante = true;
        String nombre = "Ana";

        System.out.println(nombre + " tiene " + edad + " años y mide " + altura + " metros.");
        System.out.println("¿Es estudiante? " + estudiante);
    }
}