public class ListaNombres {
    public static void main(String[] args) {
        String[] nombres = {"Ana", "Luis", "Mario"};

        for (int i = 0; i < nombres.length; i++) {
            System.out.println("Hola, " + nombres[i]);
        }
    }
}