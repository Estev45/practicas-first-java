public class Gato {
    void maullar() {
        System.out.println("¡Miau!");
    }
}

class PruebaGato {
    public static void main(String[] args) {
        Gato miGato = new Gato();
        miGato.maullar();
    }
}