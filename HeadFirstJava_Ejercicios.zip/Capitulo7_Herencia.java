class Animal {
    void hacerSonido() {
        System.out.println("Algún sonido genérico");
    }
}

class Perro extends Animal {
    void hacerSonido() {
        System.out.println("Guau guau");
    }
}

public class PruebaHerencia {
    public static void main(String[] args) {
        Animal miAnimal = new Animal();
        Perro miPerro = new Perro();

        miAnimal.hacerSonido();  // "Algún sonido genérico"
        miPerro.hacerSonido();   // "Guau guau"
    }
}