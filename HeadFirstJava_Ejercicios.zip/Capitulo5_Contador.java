public class Contador {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            if (i == 3) {
                System.out.println("¡Tres es mi número favorito!");
            } else {
                System.out.println("Número: " + i);
            }
        }
    }
}