public class Persona {
    private String nombre;

    public void setNombre(String n) {
        nombre = n;
    }

    public String getNombre() {
        return nombre;
    }
}

class PruebaPersona {
    public static void main(String[] args) {
        Persona p = new Persona();
        p.setNombre("Luis");
        System.out.println("Nombre: " + p.getNombre());
    }
}