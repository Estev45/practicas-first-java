
// Archivo: Animal.java
public class Animal {
    public void hacerSonido() {
        System.out.println("Algún sonido genérico");
    }
}
